//
//  TableViewCell.m
//  cell
//
//  Created by tangze on 16/2/16.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import "TableViewCell.h"
#import  <UIImageView+WebCache.h>
@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    [_imageVV sd_setImageWithURL:[NSURL  URLWithString:@"http://cdn.cocimg.com/bbs/attachment/upload/22/1720221416987079.jpg"] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        NSLog(@"图片加载完毕");
        
    }];
    SDWebImageManager *manager = [SDWebImageManager sharedManager];
    
    [manager downloadImageWithURL:[NSURL  URLWithString:@"http://cdn.cocimg.com/bbs/attachment/upload/22/1720221416987079.jpg"]  options:SDWebImageRetryFailed progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
        NSLog(@"显示当前进度-----------%ld,",expectedSize);
        
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
        
        NSLog(@"下载完成");
    }];

    // Configure the view for the selected state
}

@end
