//
//  TableViewCell.h
//  cell
//
//  Created by tangze on 16/2/16.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imageVV;

@end
