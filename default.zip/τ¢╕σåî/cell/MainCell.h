//
//  MainCell.h
//  cell
//
//  Created by tangze on 16/2/19.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Define.h"
@interface MainCell : UICollectionViewCell<UIGestureRecognizerDelegate,UIScrollViewDelegate,UIScrollViewAccessibilityDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate>
@property(nonatomic,strong) UIImageView * imgView;
@property (nonatomic,assign) CGPoint   img_Center;
@property (nonatomic,strong)    UIScrollView  * scrollView_main;
-(void)setCellWith:(id)data andStyle:(DataType)datatype;


@end
