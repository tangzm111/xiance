//
//  ListCell.h
//  cell
//
//  Created by tangze on 16/2/19.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Define.h"

@interface ListCell : UICollectionViewCell
@property(nonatomic,strong) UIImageView * imgView;
-(void)setCellWith:(id)data andStyle:(DataType)datatype;
//@property (nonatomic,assign) DataType dataType;
@end
