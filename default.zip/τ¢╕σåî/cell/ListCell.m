//
//  ListCell.m
//  cell
//
//  Created by tangze on 16/2/19.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import "ListCell.h"
#import <UIImageView+WebCache.h>
@interface ListCell() {
  
}
@end

@implementation ListCell
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
   
      
    
    }
    return self;
}

-(void)setCellWith:(id)data andStyle:(DataType)dataType{

    UIImageView  * imageView =[[UIImageView alloc]initWithFrame:CGRectMake(5,2.5,65, 65)];
    imageView.userInteractionEnabled=YES;

    
    
    
    switch (dataType) {
        case DataType_localStr:
            [imageView  setImage:[UIImage imageNamed:@"add_photo@1x"]];

            break;
            
        case DataType_image:
            

            imageView.image=data;
            break;
        case DataType_urlStr:
              [imageView sd_setImageWithURL:[NSURL URLWithString:(NSString *)data]];
            break;
            
        default:
            break;
    }
    
    
    
    UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    [imageView addGestureRecognizer:tap];
    [self.contentView addSubview:imageView];

    
    
     UILongPressGestureRecognizer * longPressGr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressToDo:)];
    longPressGr.minimumPressDuration = 1.0;
    [imageView addGestureRecognizer:longPressGr];
    


}

               //小图单击手势
-(void)tapAction:(UITapGestureRecognizer *)tap{
                   
     
                   
     
                   
}

//小图长按手势
-(void)longPressToDo:(UILongPressGestureRecognizer *)gesture
{
    
    if(gesture.state == UIGestureRecognizerStateBegan)
    {
        
        UIAlertView * al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"您确定要删除该图片" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
        
        [al show];
        
    }
}


@end
