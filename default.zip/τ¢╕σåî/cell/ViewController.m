//
//  ViewController.m
//  cell
//
//  Created by tangze on 16/2/16.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import "ViewController.h"
#import <UIImageView+WebCache.h>

#define WidthScreen self.view.frame.size.width
#define HeightScreen self.view.frame.size.height
@interface ViewController ()<UIGestureRecognizerDelegate,UIScrollViewDelegate,UIScrollViewAccessibilityDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>{

    CGFloat _lastScale;
    NSMutableArray * _array_data;
    
}
@property (strong, nonatomic)  UIImageView *imageVV;
@property (strong,nonatomic) UIScrollView * scroView_main;
@property (strong,nonatomic )UIScrollView * scroView_down;
@property (strong,nonatomic) UILabel * label_count;
@property (strong,nonatomic) UIButton * button_preserve;
@property (strong,nonatomic) UIView * backView;
@property (strong,nonatomic) NSMutableArray * muArray_img;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSArray *array =@[@"http://www.5068.com/u/faceimg/20140804114111.jpg",@"http://www.5068.com/u/faceimg/20140815125220.jpg",@"http://file29.mafengwo.net/M00/BE/30/wKgBpVVv-9WAVbEFAAIJXrEEzhg24.sales.h9980_w600.jpeg",@"http://t-1.tuzhan.com/f0bf09cd4968/c-1/l/2012/09/21/05/5f6ae42443f64beca920c8bcf1b3ec0f.jpg",@"http://img.my.csdn.net/uploads/201211/22/1353585511_8165.jpg",@"http://pic1.nipic.com/2009-02-19/200921922311483_2.jpg",@"http://d.hiphotos.baidu.com/image/pic/item/9f2f070828381f305a5bdb76ad014c086f06f0ab.jpg"];
    _array_data=[NSMutableArray array];
    [_array_data addObjectsFromArray:array];
    _lastScale = 1.0;
    [self creatUI];
    
    
}

-(void)creatUI{
    
    _muArray_img=[[NSMutableArray alloc]init];
    
    _backView=[[UIView alloc]initWithFrame:CGRectMake(0, 64, WidthScreen, HeightScreen-64)];
    [self.view addSubview:_backView];
    
    _label_count=[[UILabel alloc]initWithFrame:CGRectMake(0,0,WidthScreen ,40)];
    _label_count.textColor=[UIColor whiteColor];
    _label_count.font=[UIFont systemFontOfSize:13];
    _label_count.textAlignment=NSTextAlignmentCenter;
    _label_count.text=[NSString stringWithFormat:@"%d/%d",1,_array_data.count];
    _label_count.backgroundColor=[UIColor blackColor];
    [_backView addSubview:_label_count];
    [_backView bringSubviewToFront:_label_count];
    
    
    _button_preserve=[UIButton buttonWithType:0];
    _button_preserve.backgroundColor=[UIColor blackColor];
    _button_preserve.frame=CGRectMake(0,HeightScreen-64-49,WidthScreen, 49);
    [_button_preserve setTitle:@"保存" forState:0];
    [_button_preserve setTitleColor:[UIColor blackColor] forState:0];
    _button_preserve.titleLabel.textAlignment=1;
    _button_preserve.titleLabel.font=[UIFont systemFontOfSize:13];
    [_button_preserve setBackgroundColor:[UIColor whiteColor]];
    [_backView addSubview:_button_preserve];
    
    
    
    
       UIScrollView *scrollView = [[UIScrollView alloc] init];
       scrollView.frame = CGRectMake(0,40,WidthScreen,HeightScreen-49-64-40-65);

       scrollView.backgroundColor = [UIColor blackColor];
       [_backView addSubview:scrollView];
 
       // 隐藏水平滚动条
       scrollView.showsHorizontalScrollIndicator = NO;
       scrollView.showsVerticalScrollIndicator = NO;
       scrollView.bounces = NO;
       scrollView.pagingEnabled=YES;
       _scroView_main = scrollView;
    _scroView_main.delegate=self;
 
   
    _scroView_down= [[UIScrollView alloc] init];
    _scroView_down.frame = CGRectMake(0,HeightScreen-64-49-70,WidthScreen,70);

    _scroView_down.backgroundColor = [UIColor blackColor];
    [_backView addSubview:_scroView_down];
    // 隐藏水平滚动条
    _scroView_down.showsHorizontalScrollIndicator = NO;
    _scroView_down.showsVerticalScrollIndicator = NO;
    _scroView_down.delegate=self;


    
    [self reloadScrollerView];
    
    
}

-(void)reloadScrollerView{

    _scroView_main.contentSize=CGSizeMake(WidthScreen*_array_data.count, HeightScreen-49-64-40-70);
    _scroView_down.contentSize=CGSizeMake(_array_data.count*75+75,70);
    
    for (UIView * view  in  _scroView_down.subviews) {
        [view removeFromSuperview];
        
    }
    for (UIView * view in _scroView_main.subviews) {
        [view removeFromSuperview];
    }

    //大图
    for (int i=0; i<_array_data.count;i++) {
        
        UIImageView  * imageView =[[UIImageView alloc]init];
        [_muArray_img addObject:imageView];
        imageView.userInteractionEnabled=YES;
        [_scroView_main addSubview:imageView];
      

        if ([[UIImage class] isSubclassOfClass:[_array_data[i] class]]) {
            UIImage *image=_array_data[i];
            imageView.image=image;
            CGFloat  width=self.view.frame.size.width;
            CGFloat hight=self.view.frame.size.height;
            
            
            if (image.size.width<width&&image.size.height<hight) {
                imageView.frame=CGRectMake(width/2.0-image.size.width/2.0+width*i,(HeightScreen-49-64-40-65)/2.0-image.size.height/2.0, image.size.width, image.size.height);
                
            }
            else {
                CGRect frame;
                
//                if (image.size.height>image.size.width) {
//                    frame=CGRectMake(width/2-hight/image.size.height*image.size.width/2+width*i,0,hight/image.size.height*image.size.width, hight);
//                }
//                else{
                    frame=CGRectMake(5+width*i,(HeightScreen-49-64-40-65)/2.0-image.size.height/image.size.width*width/2.0,width-10, image.size.height/image.size.width*(width-10));
//                }
                imageView.frame=frame;
            }
            
            UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(scaGesture:)];
            [pinchRecognizer setDelegate:self];
            [imageView addGestureRecognizer:pinchRecognizer];
            continue;

        }

        
        [imageView sd_setImageWithURL:[NSURL  URLWithString:_array_data[i]] placeholderImage:[UIImage imageNamed:@"无标题.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            
            CGFloat  width=self.view.frame.size.width;
            CGFloat hight=self.view.frame.size.height-49-64-40-65;
            
            if (image.size.width<width&&image.size.height<hight) {
                imageView.frame=CGRectMake(width/2.0-image.size.width/2.0+width*i,(HeightScreen-49-64-40-65)/2.0-image.size.height/2.0, image.size.width, image.size.height);
                
            }
            else {
                CGRect frame;
                
//                if (image.size.height>image.size.width) {
//                frame=CGRectMake(width/2-hight/image.size.height*image.size.width/2+width*i,0,hight/image.size.height*image.size.width, hight);
//                }
//                else{
              frame=CGRectMake(5+width*i,(HeightScreen-49-64-40-65)/2.0-image.size.height/image.size.width*width/2.0,width-10, image.size.height/image.size.width*(width-10));
//                }
                imageView.frame=frame;
            }
            
           
            UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(scaGesture:)];
            [pinchRecognizer setDelegate:self];
            [imageView addGestureRecognizer:pinchRecognizer];
        }];
        
    }
    
    
    
    //小图
    for (int i=0; i<_array_data.count+1;i++) {
        
        
        
        
        UIImageView  * imageView =[[UIImageView alloc]initWithFrame:CGRectMake(5+i*65+i*5,2.5,65, 65)];
        imageView.userInteractionEnabled=YES;
        imageView.tag=200+i;
        
        
        if (_array_data.count==i) {
            
            [imageView  setImage:[UIImage imageNamed:@"add_photo@1x"]];
        }
        else if([[UIImage class] isSubclassOfClass:[_array_data[i] class]]){
            UIImage *image=_array_data[i];
            imageView.image=image;
            
            

        
        }
        
        else{
            
            [imageView sd_setImageWithURL:[NSURL URLWithString:_array_data[i]]];
            
        }
        
        UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
        [imageView addGestureRecognizer:tap];
        [_scroView_down addSubview:imageView];
        
        
        UILongPressGestureRecognizer * longPressGr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressToDo:)];
        longPressGr.minimumPressDuration = 1.0;
        [imageView addGestureRecognizer:longPressGr];

    }

}

-(void)longPressToDo:(UILongPressGestureRecognizer *)gesture
{
    if(gesture.state == UIGestureRecognizerStateBegan)
    {

        UIAlertView * al=[[UIAlertView alloc]initWithTitle:@"提示" message:@"您确定要删除该图片" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
  
    
        [al show];
    
}
}
-(void)tapAction:(UITapGestureRecognizer *)tap{
  

    UIImageView * view=(UIImageView *)tap.view;
    
    int  x=(view.tag-200)*WidthScreen;
    if (view.tag-200==_array_data.count) {
        
        
        [self openPhotograph];
        return;
    }
     _label_count.text=[NSString stringWithFormat:@"%d/%u",view.tag-200+1,_array_data.count];
    [_scroView_main setContentOffset:CGPointMake(x, 0) animated:YES];

}
-(void)openPhotograph{
   
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = YES;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:imagePickerController animated:YES completion:^{
        
    }];

}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    
//    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
  UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    

        [_array_data addObject:image];
    [self reloadScrollerView];

}


-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    int x=scrollView.contentOffset.x/WidthScreen+1;
    
    _label_count.text=[NSString stringWithFormat:@"%d/%u",x,_array_data.count];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    

//    if (_scroView_main==scrollView) {
//   float x = _scroView_main.contentOffset.x/WidthScreen*70;
//        [_scroView_down setContentOffset:CGPointMake(x, 0) animated:YES];
//    }
//
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{

    if (scrollView==_scroView_main) {
        for (UIImageView * imageView in _muArray_img) {
            
            imageView.transform=CGAffineTransformMake(1, 0, 0, 1, 0, 0) ;
        }
    }
   
}



-(void)scaGesture:(id)sender {
    [self.view bringSubviewToFront:[(UIPinchGestureRecognizer*)sender view]];
    //当手指离开屏幕时,将lastscale设置为1.0
    if([(UIPinchGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
        _lastScale = 1.0;
        return;
    }
    
    CGFloat scale = 1.0 - (_lastScale - [(UIPinchGestureRecognizer*)sender scale]);
    CGAffineTransform currentTransform = [(UIPinchGestureRecognizer*)sender view].transform;
   
    if ([(UIPinchGestureRecognizer*)sender view].transform.a<0.5&&scale<1.0) {
        return;
        }
    
    if([(UIPinchGestureRecognizer*)sender view].transform.a>2&&scale>1.0){
        return;
        }
    
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, scale, scale);
    [[(UIPinchGestureRecognizer*)sender view]setTransform:newTransform];
    _lastScale = [(UIPinchGestureRecognizer*)sender scale];
}
#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return ![gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
