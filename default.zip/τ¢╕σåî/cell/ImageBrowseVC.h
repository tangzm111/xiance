//
//  ImageBrowseVC.h
//  cell
//
//  Created by tangze on 16/2/19.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageBrowseVC : UIViewController

@end
