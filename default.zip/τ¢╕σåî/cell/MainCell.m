//
//  MainCell.m
//  cell
//
//  Created by tangze on 16/2/19.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import "MainCell.h"
#import <UIImageView+WebCache.h>

@interface MainCell() {
 CGFloat    _lastScale  ;
    UIPanGestureRecognizer* _panGestureRecognizer;
    BOOL    PanOpen;

}
@end
@implementation MainCell
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        
        
    }
    return self;
}

-(void)setCellWith:(id)data andStyle:(DataType)dataType{

    
    
    [_scrollView_main removeFromSuperview];
     [_imgView removeFromSuperview];
    
     _scrollView_main=[[UIScrollView alloc]initWithFrame:self.contentView.bounds];
   
    _scrollView_main.backgroundColor=[UIColor redColor];
    
    [self.contentView addSubview:_scrollView_main];
    _scrollView_main.bounces=YES;
    _scrollView_main.scrollEnabled=NO;
  
    
    UIImageView  * imageView =[[UIImageView alloc]initWithFrame:CGRectMake(5,2.5,65, 65)];
    imageView.userInteractionEnabled=YES;
       _imgView=imageView;
    CGFloat  width=self.contentView.frame.size.width;
    CGFloat hight=self.contentView.frame.size.height;

    PanOpen=NO;
    
    switch (dataType) {
            
        case DataType_image:
            
            
            imageView.image=data;
            
            if ( imageView.image.size.width<width&& imageView.image.size.height<hight) {
                imageView.frame=CGRectMake(width/2.0- imageView.image.size.width/2.0,hight/2.0- imageView.image.size.height/2.0, imageView.image.size.width,  imageView.image.size.height);
                
            }
            else {
                CGRect frame;
                
                if ( imageView.image.size.height/ imageView.image.size.width*(width-10)>hight) {
                    
                    frame=CGRectMake(width/2-(hight-10)/imageView.image.size.height*imageView.image.size.width/2,5,(hight-10)/ imageView.image.size.height*imageView.image.size.width,(hight-10));
                }
                else{
                    frame=CGRectMake(5,hight/2.0-imageView.image.size.height/imageView.image.size.width*(width-10)/2,width-10, imageView.image.size.height/imageView.image.size.width*(width-10));
                }
                imageView.frame=frame;
                
                
            }
            
            float  wid=_imgView.frame.size.width;
            float hei=_imgView.frame.size.height;
            _scrollView_main.contentSize=CGSizeMake(width*2-wid,hight*2-hei);
            _imgView.center=CGPointMake((width*2-wid)/2.0,(hight*2-hei)/2.0);
            [_scrollView_main setContentOffset:CGPointMake((width-wid)/2,(hight-hei)/2.0)];
            _img_Center=imageView.center;

            break;
        case DataType_urlStr:
            
            [imageView sd_setImageWithURL:[NSURL  URLWithString:(NSString *)data] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                
                
                if ( imageView.image.size.width<width&& imageView.image.size.height<hight) {
                    imageView.frame=CGRectMake(width/2.0- imageView.image.size.width/2.0,hight/2.0- imageView.image.size.height/2.0, imageView.image.size.width,  imageView.image.size.height);
                    
                }
                else {
                    CGRect frame;
                    
                    if ( imageView.image.size.height/ imageView.image.size.width*(width-10)>hight) {
 
                        frame=CGRectMake(width/2-(hight-10)/imageView.image.size.height*imageView.image.size.width/2,5,(hight-10)/ imageView.image.size.height*imageView.image.size.width,(hight-10));
                    }
                    else{
                        frame=CGRectMake(5,hight/2.0-imageView.image.size.height/imageView.image.size.width*(width-10)/2,width-10, imageView.image.size.height/imageView.image.size.width*(width-10));
                    }
                    imageView.frame=frame;

            
                }
                
                float  wid=_imgView.frame.size.width;
                float hei=_imgView.frame.size.height;
                _scrollView_main.contentSize=CGSizeMake(width*2-wid,hight*2-hei);
                _imgView.center=CGPointMake((width*2-wid)/2.0,(hight*2-hei)/2.0);
                [_scrollView_main setContentOffset:CGPointMake((width-wid)/2,(hight-hei)/2.0)];
                          _img_Center=imageView.center;
            }];
     

            break;
            
      
    }
    
    
  
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(scaGesture:)];
        [pinchRecognizer setDelegate:self];
        [self.contentView addGestureRecognizer:pinchRecognizer];
    
        
        UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(MianImagetapAction:)];
        tap.numberOfTapsRequired=2;
        [imageView addGestureRecognizer:tap];
    

        [_scrollView_main addSubview:imageView];
}

//大图双击事件
-(void)MianImagetapAction:(UITapGestureRecognizer *)tap{
     _scrollView_main.scrollEnabled=YES;
     UIImageView * imageView= (UIImageView *)tap.view;

    CGAffineTransform currentTransform = imageView.transform;
    CGAffineTransform  standerTransform=CGAffineTransformMake(1, 0, 0, 1, 0, 0);
    if (currentTransform.a==1&&currentTransform.d==1) {
        imageView.transform=CGAffineTransformMake(2, 0, 0, 2, 0, 0);
    
    }else{
        
        imageView.transform=standerTransform;
        _scrollView_main.scrollEnabled=NO;

    }
     [self  reSetImgeCenterAndScrollContentSize];
    
    
    [_scrollView_main setContentOffset:CGPointMake((_scrollView_main.contentSize.width-self.contentView.frame.size.width)/2,(_scrollView_main.contentSize.height-self.contentView.frame.size.height)/2)];

}
//大图缩放
-(void)scaGesture:(id)sender {
   
    
    _scrollView_main.scrollEnabled=YES;


    //当手指离开屏幕时,将lastscale设置为1.0
    
    if([(UIPinchGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
        _lastScale = 1.0;
        return;
    }
    
    CGFloat scale = 1.0 - (_lastScale - [(UIPinchGestureRecognizer*)sender scale]);
    CGAffineTransform currentTransform =_imgView.transform;
    
    if (_imgView.transform.a<0.5&&scale<1.0) {
        return;
    }
    
    if(_imgView.transform.a>3&&scale>1.0){
        return;
    }
    
    CGAffineTransform newTransform = CGAffineTransformScale(currentTransform, scale, scale);
    [_imgView setTransform:newTransform];
    _lastScale = [(UIPinchGestureRecognizer*)sender scale];
    
    
    
 
    [self  reSetImgeCenterAndScrollContentSize];

}
//设置图片中心点和scroll大小
-(void)reSetImgeCenterAndScrollContentSize{

    CGFloat  width=self.contentView.frame.size.width;
    CGFloat hight=self.contentView.frame.size.height;
    float  wid=_imgView.frame.size.width;
    float hei=_imgView.frame.size.height;
    
    if (wid<=width&&hei<=hight) {
        _scrollView_main.contentSize=CGSizeMake(width*2-wid,hight*2-hei);
        _imgView.center=CGPointMake((width*2-wid)/2.0,(hight*2-hei)/2.0);
        
    }
    else if(wid<=width&&hei>hight){
        
        _scrollView_main.contentSize=CGSizeMake(width*2-wid,hei);
        _imgView.center=CGPointMake((width*2-wid)/2.0,hei/2.0);
        
    }else if(wid>width&&hei<=hight){
        
        _scrollView_main.contentSize=CGSizeMake(wid,hight*2-hei);
        _imgView.center=CGPointMake(wid/2.0,(hight*2-hei)/2.0);
        
    }else{
        
        _scrollView_main.contentSize=CGSizeMake(wid,hei);
        _imgView.center=CGPointMake(wid/2.0,hei/2.0);
        
        
    }

    _img_Center=_imgView.center;
}

//大图拖拽手势
- (void)handlePan:(UIPanGestureRecognizer*) recognizer
{
  
    
    CGPoint translation = [recognizer translationInView:self.contentView];
    
   
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointZero inView:self.contentView];
    
    NSLog(@"%lf,%lf",_imgView.center.x,_imgView.center.y);
    
    
    float x;
    if (_imgView.center.x<=0) {
        x=-_imgView.center.x+self.contentView.frame.size.width;
    }else{
    
        x=_imgView.center.x+self.contentView.frame.size.width/2;
    }
    
    
    
    if (x>=_imgView.frame.size.width/2.0) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"scrollViewEnable" object:nil];
    }
    
    if (recognizer.state == UIGestureRecognizerStateEnded) {
        
        CGPoint velocity = [recognizer velocityInView:self.contentView];
        CGFloat magnitude = sqrtf((velocity.x * velocity.x) + (velocity.y * velocity.y));
        CGFloat slideMult = magnitude / 200;
        
        
        float slideFactor = 0.1 * slideMult; // Increase for more of a slide
                CGPoint finalPoint = CGPointMake(recognizer.view.center.x + (velocity.x * slideFactor),
                                                 recognizer.view.center.y + (velocity.y * slideFactor));
                finalPoint.x = MIN(MAX(finalPoint.x, 0), self.contentView.bounds.size.width);
                finalPoint.y = MIN(MAX(finalPoint.y, 0), self.contentView.bounds.size.height);
        
        UIView * view=recognizer.view;
        
               [UIView animateWithDuration:slideFactor delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            recognizer.view.center =_img_Center;
        } completion:nil];
    }
}



@end
