//
//  Define.h
//  cell
//
//  Created by tangze on 16/2/25.
//  Copyright © 2016年 com.accelerate. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{

    DataType_localStr=0,
    DataType_image,
    DataType_urlStr,
}DataType;
